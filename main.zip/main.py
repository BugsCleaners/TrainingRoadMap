from fastapi import FastAPI
import uvicorn

app = FastAPI()

@app.get("/hello")
def hello (message='Hellen'):
    return 'Welcome from the heaven 2 , '+message

if __name__ == '__main__':
    uvicorn.run('main:app', host='0.0.0.0', port=8000)

# az login
# az login --service-principal --username 712098a8-d9b4-4299-9666-8e1a1de517ae --password 7AO8Q~XtDYLFSAdVXY6tJvoFaAMGYZC6ctJCfcPf --tenant 4ba10ae4-87c6-4077-902b-59be44fb3c37
# az webapp deploy  --name otest   --resource-group rg1  --src-path main.zip 
