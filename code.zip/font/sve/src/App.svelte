<script>
  let name = "";
  let response = "";

  async function submitForm() {
      const data = { name };

      try {
          const res = await fetch("http://127.0.0.1:8090/items/", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(data),
          });
          const result = await res.json();
          if (res.ok) {
              response = result.message + ": " +result.data;
          } else {
              response = result.detail;
          }
      } catch (err) {
          response = "An error occurred: " + err.message;
      }
  }
</script>

<style>
  form {
      display: flex;
      flex-direction: column;
      max-width: 300px;
      margin: auto;
  }
  input, textarea, button {
      margin: 10px 0;
  }
</style>

<h1>FastAPI + Svelte</h1>

<form on:submit|preventDefault={submitForm}>
  <input
      type="text"
      placeholder="Name"
      bind:value={name}
      required
  />
  <button type="submit">Submit</button>
</form>

{#if response}
  <p>{response}</p>
{/if}
