from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
app = FastAPI()


app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

# Data model for the POST request
class Item(BaseModel):
    name: str

# POST endpoint
@app.post("/items/")
async def create_item(item: Item):
    # Simple validation or processing
    if not item.name :
        raise HTTPException(status_code=400, detail="Name is required")
    return {"message": "Item received successfully", "data": item.name}


if __name__ == "__main__":
   uvicorn.run(app, host="0.0.0.0", port=8090)



# from fastapi import FastAPI, HTTPException
# import uvicorn

# app = FastAPI()

# @app.get("/hello")
# async def hello(message='test'):
   
#     return {"Hello ":message}

# if __name__ == "__main__":

#     uvicorn.run(app, host="127.0.0.1", port=8080)