from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from fastapi.staticfiles import StaticFiles
import os
app = FastAPI()


app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

# Data model for the POST request
class Item(BaseModel):
    name: str

# POST endpoint
@app.post("/items/")
async def create_item(item: Item):
    # Simple validation or processing
    if not item.name :
        raise HTTPException(status_code=400, detail="Name is required")
    return {"message": "Item received successfully", "data": item.name}


base_dir = os.path.dirname(os.path.abspath(__file__))  # Gets the directory where main.py is located
static_files_path = os.path.join(base_dir, "../public")

# Serve the static files
app.mount("/", StaticFiles(directory=static_files_path, html=True), name="static")



if __name__ == "__main__":

    uvicorn.run(app, host="0.0.0.0", port=8000)